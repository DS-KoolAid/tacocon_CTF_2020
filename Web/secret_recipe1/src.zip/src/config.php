<?php

$MYSQL_HOST = "mysql-server";
$MYSQL_USERNAME = "root";
$MYSQL_PASSWORD = "je6H92Gagf91Ha";
$MYSQL_DBNAME = "tacocon";